window.onload = function () {
    let taulaInventari = document.getElementById('taulaInventari');
    let llistaInventari = JSON.parse(localStorage.getItem('llistaInventari')) || [];
    let selectAllCheckbox = document.getElementById('selectAll');
    let botoFinalitzar = document.getElementById('finalitzar');
    let botoModificar = document.getElementById('modificar');
    let botoTornar =  document.getElementById('tornar');


    // Carrega les dades de l'inventari a la taula
    function carregarTaula() {
        taulaInventari.innerHTML = ''; // Buida la taula

        llistaInventari.forEach(item => {
            const fila = document.createElement('tr');
            fila.innerHTML = `
                <td><input type="checkbox" class="rowCheckbox" data-id="${item.id}" /></td>
                <td>${item.id}</td>
                <td>${item.id_inventory}</td>
                <td contenteditable="true" class="editable">${item.quantity_real}</td>
                <td>
                    <select class="editable">
                        <option value="Trencat" ${item.inventory_reason === 'Trencat' ? 'selected' : ''}>Trencat</option>
                        <option value="Robatori" ${item.inventory_reason === 'Robatori' ? 'selected' : ''}>Robatori</option>
                        <option value="Desaparegut" ${item.inventory_reason === 'Desaparegut' ? 'selected' : ''}>Desaparegut</option>
                        <option value="Error administratiu" ${item.inventory_reason === 'Error administratiu' ? 'selected' : ''}>Error administratiu</option>
                        <option value="Recompte cíclic" ${item.inventory_reason === 'Recompte cíclic' ? 'selected' : ''}>Recompte cíclic</option>
                    </select>
                </td>
                <td>${item.operator_id}</td>
                <td>${item.created_by}</td>
                <td>${item.date_inventory}</td>
                <td>${item.estat}</td>
            `;
            taulaInventari.appendChild(fila);
        });
    }

    // Selecciona o desselecciona tots els checkbox
    function toggleSelectAll() {
        const checkboxes = document.querySelectorAll('.rowCheckbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = selectAllCheckbox.checked;
        });
    }

    // Elimina les files seleccionades
    function finalitzarSeleccio() {
        const checkboxesSeleccionats = document.querySelectorAll('.rowCheckbox:checked');
        const idsAEliminar = Array.from(checkboxesSeleccionats).map(checkbox => checkbox.getAttribute('data-id'));

        llistaInventari = llistaInventari.filter(item => !idsAEliminar.includes(item.id.toString()));

        localStorage.setItem('llistaInventari', JSON.stringify(llistaInventari));
        carregarTaula();
        selectAllCheckbox.checked = false;
    }

    // Modifica les files seleccionades i guarda els canvis
    function modificarSeleccio() {
        const checkboxesSeleccionats = document.querySelectorAll('.rowCheckbox:checked');

        checkboxesSeleccionats.forEach(checkbox => {
            const fila = checkbox.parentElement.parentElement;
            const id = checkbox.getAttribute('data-id');

            // Captura el valor del camp editable quantity_real
            const quantityReal = fila.querySelector('.editable').innerText;

            // Captura el valor del select per a inventory_reason
            const inventoryReason = fila.querySelector('select').value;

            // Busca l'element en llistaInventari amb el mateix ID i actualitza els valors
            const item = llistaInventari.find(item => item.id.toString() === id);
            if (item) {
                item.quantity_real = quantityReal;
                item.inventory_reason = inventoryReason;
            }
        });

        // Guarda els canvis en localStorage
        localStorage.setItem('llistaInventari', JSON.stringify(llistaInventari));
        carregarTaula(); // Recarrega la taula per veure els canvis aplicats
        selectAllCheckbox.checked = false;
    }

    carregarTaula();

    // Esdeveniments
    selectAllCheckbox.addEventListener('change', toggleSelectAll);
    botoTornar.addEventListener('click', function(){
        window.location.href = '../index.html';
    });
    botoFinalitzar.addEventListener('click', finalitzarSeleccio);
    botoModificar.addEventListener('click', modificarSeleccio);

    // Captura els  canvis en la taula
    console.log("Modificant item:", item);
    console.log("Quantitat real capturada:", quantityReal);
    console.log("Raó de l'inventari capturada:", inventoryReason);
};
