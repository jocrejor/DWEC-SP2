window.onload = function () {
    let form = document.getElementById('formInventari');
    let id = document.getElementById('id');
    let realQuantity = document.getElementById('quantity_real');
    let inventoryReason = document.getElementById('inventory_reason');
    let botoLlista = document.getElementById('botoLlista'); 

    // Configurar ID automàticament (després al guardar en el localStorage es considerará el nombre de ID's)
    let llistaInventari = JSON.parse(localStorage.getItem('llistaInventari')) || [];
    id.value = llistaInventari.length > 0 ? llistaInventari[llistaInventari.length - 1].id + 1 : 1;

    // Configurar altres  camps automàticament (quantitat i motiu de l'inventari)
    realQuantity.value = 0;
    inventoryReason.value = 0;

    // Data automàticament ficada, per tal de qui faça l'inventari no tinga que poder manipular-la
    var hui = new Date();
    var dia = ('0' + hui.getDate()).slice(-2);
    var mes = ('0' + (hui.getMonth() + 1)).slice(-2);
    var any = hui.getFullYear();
    const dataFormatada = dia + '/' + mes + '/' + any; //formatem la  data en el format europeu (fck eeuu)
    document.getElementById('date_inventory').value = dataFormatada; //per emplenar el camp  de la data d'inventari

    // Event Listener per a quan clickem en el botó Llista ens dirigisca a la  pàgina de llistat de inventari
    botoLlista.addEventListener('click', function (event) {
        window.location.href = '/html/llistaInventari.html' ;
        });


    /* Afegir un event listener al formulari per gestionar l'enviament
     En evitar l'acció per defecte, es recullen les dades del formulari, 
     es creen un objecte itemInventari amb les dades corresponents, 
     i es desa en localStorage. També s'incrementa l'ID per al proper registre 
     i es reinicia el formulari per facilitar l'entrada de nous registres. 
     */
    form.addEventListener('submit', function (event) {
        event.preventDefault();

        // Validar que els camps no estiguen buits
        if (!id.value || !document.getElementById('id_inventory').value ||
            !realQuantity.value || !inventoryReason.value ||
            !document.getElementById('operator_id').value ||
            !document.getElementById('created_by').value ||
            !document.getElementById('estat').value) {
            alert('Tots els camps són obligatoris.');
            return;
        }

        const itemInventari = {
            id: parseInt(id.value),
            id_inventory: document.getElementById('id_inventory').value,
            quantity_real: parseInt(realQuantity.value),
            inventory_reason: parseInt(inventoryReason.value),
            operator_id: document.getElementById('operator_id').value,
            created_by: document.getElementById('created_by').value,
            date_inventory: dataFormatada,
            estat: document.getElementById('estat').value
        };

        // Guardar en localStorage
        llistaInventari.push(itemInventari);
        localStorage.setItem('llistaInventari', JSON.stringify(llistaInventari));

        console.log('Contingut de localStorage: ', localStorage.getItem('llistaInventari'));
        
        // Reiniciar el formulari
        form.reset();
        dataFormatada;
        // Incrementar el ID per al següent registre
        id.value = itemInventari.id + 1;
    });
};
