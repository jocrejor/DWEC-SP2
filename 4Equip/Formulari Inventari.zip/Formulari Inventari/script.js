document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const users = {
        'operari': 'ops123@',
        'admin': 'admin123@',
        'encarregat': 'enc123@'
    };

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username === 'operari' && password === users['operari']) {
        window.location.href = '/html/llistaInventari.html';
    } else if (username === 'admin' && password === users['admin']) {
        window.location.href = '/html/generaInventari.html';
    } else if (username === 'encarregat' && password === users['encarregat']) {
        window.location.href = '/html/generaInventari.html';
    } else {
        alert('Usuari o contrasenya incorrectes. Si us plau, torna a intentar-ho.');
    }
});
