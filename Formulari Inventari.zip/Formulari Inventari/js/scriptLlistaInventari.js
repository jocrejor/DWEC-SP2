window.onload = function () {
    let taulaInventari = document.getElementById('taulaInventari');
    let llistaInventari = JSON.parse(localStorage.getItem('llistaInventari')) || [];
    let botoTorna = document.getElementById('redireccio');

    llistaInventari.forEach(item => {
        const fila = document.createElement('tr');

        // Crea i afegeig una fila  a la taula amb els elements necessaris
        fila.innerHTML = `
            <td>${item.id}</td>
            <td>${item.id_inventory}</td>
            <td>${item.quantity_real}</td>
            <td>${item.inventory_reason}</td>
            <td>${item.operator_id}</td>
            <td>${item.created_by}</td>
            <td>${item.date_inventory}</td>
            <td>${item.estat}</td>
        `;

        taulaInventari.appendChild(fila);
    });

    // Quan clickem el botó de tornar , ens tornarà a index.html
    botoTorna.addEventListener('click', function(){
        window.location.href = '/index.html';
    });


};
